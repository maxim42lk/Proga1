﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proga1_lab1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double PI = 3.14159265;
            string P = textBox1.Text;
            string R = textBox2.Text;
            string M = textBox3.Text;
            double P_1 = Convert.ToDouble(P);
            double R_1 = Convert.ToDouble(R);
            double M_1 = Convert.ToDouble(M);
            double Thickness = M_1 / (P_1 * R_1 * 2 * PI);
            textBox4.Text = Thickness.ToString();
        }
    }
}
